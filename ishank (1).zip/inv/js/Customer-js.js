const fashion = document.getElementById("Customer-fashion");
const Electronics = document.getElementById("Customer-electronics");
const ElApp = document.getElementById("Customer-ElApp");
const Grocery = document.getElementById("Customer-grocery");
const Home = document.getElementById("Customer-home");
const Beauty = document.getElementById("Customer-beauty");

fashion.addEventListener("click", (e) => {
    e.preventDefault();
    alert('abc');
})